# Lakewood Grocery Price Compare

Compares grocery prices across local Lakewood, NJ kosher grocers. A scheduled
robot pulls live prices; a phone-friendly web page lets you search items, see
which store is cheapest, and build a shopping list.

**Right now it covers: Seasons** (the first store). More stores get added by
dropping additional scrapers into `scrapers/`.

## What's in here
- `scrape.js` + `scrapers/` — the price robot (Node + Playwright)
- `.github/workflows/update-prices.yml` — runs the robot daily, saves prices
- `index.html` — the web app (reads `data/prices.json`)
- `data/prices.json` — the latest prices (overwritten by the robot)

---

## One-time setup (about 10 minutes, no coding)

### 1. Make a free GitHub account
Go to https://github.com and sign up if you don't have one.

### 2. Create a new repository
- Click the **+** (top right) → **New repository**
- Name it `lakewood-grocery` (anything is fine)
- Set it to **Public**
- Click **Create repository**

### 3. Upload these files
- On the new repo page, click **uploading an existing file**
- Drag in **all** the files and folders from this bundle (keep the folder
  structure: `.github/`, `scrapers/`, `data/`, and the loose files)
- Click **Commit changes**

> Tip: if drag-and-drop won't keep folders, use **Add file → Upload files**
> and drag the whole unzipped folder in at once.

### 4. Turn on the price robot
- Go to the **Actions** tab
- If prompted, click **"I understand my workflows, enable them"**
- Click **Update grocery prices** on the left → **Run workflow** → **Run workflow**
- Wait ~2 minutes. When it finishes green, `data/prices.json` now holds real
  Seasons prices.

### 5. Turn on the website
- Go to **Settings → Pages**
- Under **Source**, pick **Deploy from a branch**
- Branch: **main**, folder: **/ (root)** → **Save**
- After a minute, your live site is at:
  `https://YOUR-USERNAME.github.io/lakewood-grocery/`
- Open that on your phone and add it to your home screen.

That's it. The robot re-checks prices every day automatically. You can also
hit **Run workflow** any time to refresh on demand.

---

## Running it on your own computer instead (optional)
If you'd rather test locally: install Node (https://nodejs.org), then in this
folder run:
```
npm install
npx playwright install chromium
npm run scrape
```
This writes `data/prices.json`. Open `index.html` through a local server
(e.g. `npx serve`) to view it.

## Adding more stores
Each store is one file in `scrapers/`. Copy `scrapers/seasons.js` as a
template, point it at the next store, and add it to the list in `scrape.js`.
The web app automatically shows any new store that appears in the data.

## Notes & limits
- **Item matching across stores** is approximate — stores name the same
  product differently ("Large Eggs Dozen" vs "Eggs Large Dozen"). The app
  groups by a normalized name; some items won't line up perfectly yet. This is
  the main area to improve as more stores come online.
- Scraping public prices for personal price-comparison is generally fine, but
  it's good practice to keep request volume light (this runs once a day).
- If a store redesigns its site, its scraper may need a quick tune-up.
